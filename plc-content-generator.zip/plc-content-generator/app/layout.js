import "./globals.css";

export const metadata = {
  title: "PLC Direct — Product Content Generator",
  description: "Bulk AI product content generation for PLC Direct team",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
