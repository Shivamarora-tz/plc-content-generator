"use client";
import { useState, useRef, useEffect, useCallback } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────

const OUTPUT_FIELDS = [
  "input_part_number","input_brand","input_context",
  "productName","brand","partNumber",
  "shortDescription","overview",
  "info_productType","info_series","info_formFactor",
  "info_condition","info_warranty","info_shipping","info_availability",
  "keyBenefits","technicalSpecifications","additionalBenefits","applications",
  "facets_category","facets_brand","facets_series","facets_productType",
  "facets_protocols","facets_industries","facets_tags",
  "criticalInformation","status","error","processed_at",
];

// ─── Utilities ────────────────────────────────────────────────────────────────

function parseCSV(text) {
  const lines = text.trim().split(/\r?\n/);
  if (lines.length < 2) return { headers: [], rows: [] };
  function parseLine(line) {
    const cols = []; let cur = ""; let q = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"' && !q) { q = true; }
      else if (c === '"' && q) { if (line[i+1] === '"') { cur += '"'; i++; } else { q = false; } }
      else if (c === "," && !q) { cols.push(cur.trim()); cur = ""; }
      else cur += c;
    }
    cols.push(cur.trim());
    return cols;
  }
  const headers = parseLine(lines[0]).map(h => h.replace(/^\uFEFF/, "").replace(/"/g, ""));
  const rows = lines.slice(1).filter(l => l.trim()).map(l => {
    const vals = parseLine(l);
    const obj = {};
    headers.forEach((h, i) => { obj[h] = vals[i] ?? ""; });
    return obj;
  });
  return { headers, rows };
}

function makeCSV(results) {
  const esc = v => {
    const s = String(v ?? "");
    return (s.includes(",") || s.includes('"') || s.includes("\n"))
      ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  return [OUTPUT_FIELDS.join(","), ...results.map(r => OUTPUT_FIELDS.map(f => esc(r[f])).join(","))].join("\n");
}

function downloadCSV(results, filename) {
  const blob = new Blob([makeCSV(results)], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function flattenResult(data, pn, brand, ctx) {
  const fi = data.productInformation || {};
  const fc = data.facets || {};
  return {
    input_part_number: pn, input_brand: brand, input_context: ctx,
    productName: data.productName || "", brand: data.brand || "", partNumber: data.partNumber || "",
    shortDescription: data.shortDescription || "", overview: data.overview || "",
    info_productType: fi["Product Type"] || "", info_series: fi["Series / Family"] || "",
    info_formFactor: fi["Form Factor"] || "",
    info_condition: fi["Condition (PLC Direct)"] || "Surplus / Refurbished / Used",
    info_warranty: fi["Warranty"] || "1 Year (PLC Direct)",
    info_shipping: fi["Shipping"] || "Free (US)",
    info_availability: fi["Availability"] || "Subject to stock",
    keyBenefits: (data.keyBenefits || []).join(" | "),
    technicalSpecifications: JSON.stringify(data.technicalSpecifications || {}),
    additionalBenefits: (data.additionalBenefits || []).join(" | "),
    applications: (data.applications || []).join(" | "),
    facets_category: fc["Category"] || "", facets_brand: fc["Brand"] || "",
    facets_series: fc["Series"] || "", facets_productType: fc["Product Type"] || "",
    facets_protocols: (fc["Communication Protocols"] || []).join(" | "),
    facets_industries: (fc["Industries"] || []).join(" | "),
    facets_tags: (fc["Tags"] || []).join(" | "),
    criticalInformation: (data.criticalInformation || []).join(" | "),
    status: "success", error: "", processed_at: new Date().toISOString(),
  };
}

function makeFailedRow(pn, brand, ctx, errMsg) {
  const r = {};
  OUTPUT_FIELDS.forEach(f => { r[f] = ""; });
  return { ...r, input_part_number: pn, input_brand: brand, input_context: ctx, status: "failed", error: errMsg, processed_at: new Date().toISOString() };
}

function autoDetect(headers) {
  const lc = headers.map(h => h.toLowerCase());
  const find = keys => { const i = lc.findIndex(h => keys.some(k => h.includes(k))); return i >= 0 ? headers[i] : ""; };
  return {
    pn: find(["part_number","part number","partnum","pn","sku","model_number","model number","item_number","item","part"]),
    brand: find(["brand","manufacturer","mfr","make","vendor","supplier"]),
    ctx: find(["context","note","description","detail","info","additional","extra"]),
  };
}

function fmtTime(sec) {
  if (!sec || sec <= 0) return "—";
  if (sec < 60) return `${Math.round(sec)}s`;
  if (sec < 3600) return `${Math.round(sec / 60)}m`;
  return `${(sec / 3600).toFixed(1)}h`;
}

// ─── API call (goes to our secure backend) ────────────────────────────────────

async function callGenerate(pn, brand, ctx) {
  const teamPassword = localStorage.getItem("plc_team_password") || "";
  const res = await fetch("/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-team-password": teamPassword },
    body: JSON.stringify({ pn, brand, ctx }),
  });
  if (res.status === 429) { const e = new Error("rate_limit"); e.isRateLimit = true; throw e; }
  if (res.status === 401) { const e = new Error("unauthorized"); e.isUnauthorized = true; throw e; }
  if (!res.ok) throw new Error(`Server error ${res.status}`);
  const json = await res.json();
  if (!json.success) throw new Error(json.error || "Unknown error");
  return json.data;
}

// ─── Step Indicator ───────────────────────────────────────────────────────────

function Steps({ step }) {
  const steps = ["upload", "preview", "processing", "complete"];
  const labels = ["Upload", "Configure", "Processing", "Complete"];
  const idx = steps.indexOf(step);
  return (
    <div className="steps">
      {steps.map((s, i) => {
        const done = i < idx; const active = i === idx;
        return (
          <div key={s} className="step-item">
            <div className="step-col">
              <div className={`step-circle ${done ? "done" : active ? "active" : "idle"}`}>
                {done ? "✓" : i + 1}
              </div>
              <span className={`step-label ${done ? "done" : active ? "active" : "idle"}`}>{labels[i]}</span>
            </div>
            {i < steps.length - 1 && <div className={`step-connector ${done ? "done" : ""}`} />}
          </div>
        );
      })}
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function Home() {
  const [step, setStep] = useState("upload");
  const [dragOver, setDragOver] = useState(false);
  const [fileInfo, setFileInfo] = useState(null);
  const [headers, setHeaders] = useState([]);
  const [rows, setRows] = useState([]);
  const [colMap, setColMap] = useState({ pn: "", brand: "", ctx: "" });
  const [concurrency, setConcurrency] = useState(5);
  const [isPaused, setIsPaused] = useState(false);
  const [teamPassword, setTeamPassword] = useState("");
  const [showPwInput, setShowPwInput] = useState(false);

  const resultsRef = useRef([]);
  const queueIdxRef = useRef(0);
  const pausedRef = useRef(false);
  const stoppedRef = useRef(false);
  const statsRef = useRef({ processed: 0, succeeded: 0, failed: 0, startTime: null });
  const recentRef = useRef([]);

  const [disp, setDisp] = useState({ processed: 0, succeeded: 0, failed: 0, rate: 0, eta: "—" });
  const [recentItems, setRecentItems] = useState([]);

  // Load saved password on mount
  useEffect(() => {
    const saved = localStorage.getItem("plc_team_password");
    if (saved) setTeamPassword(saved);
  }, []);

  // Stats ticker
  useEffect(() => {
    if (step !== "processing") return;
    const timer = setInterval(() => {
      const s = statsRef.current;
      const elapsed = s.startTime ? (Date.now() - s.startTime) / 1000 : 1;
      const rate = elapsed > 1 ? (s.processed / elapsed) * 60 : 0;
      const remaining = rows.length - s.processed;
      const etaSec = rate > 0 ? (remaining / rate) * 60 : null;
      setDisp({ ...s, rate: Math.round(rate * 10) / 10, eta: etaSec !== null ? fmtTime(etaSec) : "—" });
      setRecentItems([...recentRef.current]);
    }, 700);
    return () => clearInterval(timer);
  }, [step, rows.length]);

  function loadFile(file) {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".csv")) { alert("Please upload a .csv file."); return; }
    const reader = new FileReader();
    reader.onload = e => {
      const { headers: hdrs, rows: rws } = parseCSV(e.target.result);
      if (!hdrs.length || !rws.length) { alert("Could not parse CSV. Please check the format."); return; }
      setHeaders(hdrs);
      setRows(rws);
      setFileInfo({ name: file.name, size: (file.size / 1024).toFixed(0), count: rws.length });
      setColMap(autoDetect(hdrs));
      setStep("preview");
    };
    reader.readAsText(file);
  }

  async function worker(mappedRows) {
    while (!stoppedRef.current) {
      while (pausedRef.current && !stoppedRef.current) {
        await new Promise(r => setTimeout(r, 400));
      }
      if (stoppedRef.current) break;
      const idx = queueIdxRef.current++;
      if (idx >= mappedRows.length) break;
      const { pn, brand, ctx } = mappedRows[idx];
      let result; let attempts = 0;
      while (attempts < 3) {
        try {
          const data = await callGenerate(pn, brand, ctx);
          result = flattenResult(data, pn, brand, ctx);
          statsRef.current.succeeded++;
          break;
        } catch (err) {
          if (err.isUnauthorized) {
            stoppedRef.current = true;
            alert("Incorrect team password. Please update it in Settings.");
            return;
          }
          attempts++;
          if (err.isRateLimit) { await new Promise(r => setTimeout(r, 12000)); }
          else if (attempts >= 3) { result = makeFailedRow(pn, brand, ctx, err.message); statsRef.current.failed++; }
          else { await new Promise(r => setTimeout(r, 2000 * attempts)); }
        }
      }
      if (!result) { result = makeFailedRow(pn, brand, ctx, "Max retries exceeded"); statsRef.current.failed++; }
      resultsRef.current.push(result);
      statsRef.current.processed++;
      recentRef.current = [{ pn, brand, status: result.status, name: result.productName || "" }, ...recentRef.current].slice(0, 10);
    }
  }

  async function startProcessing() {
    resultsRef.current = [];
    queueIdxRef.current = 0;
    pausedRef.current = false;
    stoppedRef.current = false;
    statsRef.current = { processed: 0, succeeded: 0, failed: 0, startTime: Date.now() };
    recentRef.current = [];
    setDisp({ processed: 0, succeeded: 0, failed: 0, rate: 0, eta: "—" });
    setRecentItems([]);
    setIsPaused(false);
    setStep("processing");

    const mappedRows = rows.map(r => ({
      pn: (r[colMap.pn] || "").trim(),
      brand: (r[colMap.brand] || "").trim(),
      ctx: colMap.ctx ? (r[colMap.ctx] || "").trim() : "",
    }));

    const workers = Array.from({ length: concurrency }, () => worker(mappedRows));
    await Promise.all(workers);

    if (!stoppedRef.current) {
      const s = statsRef.current;
      const elapsed = s.startTime ? (Date.now() - s.startTime) / 1000 : 1;
      setDisp(prev => ({ ...prev, ...s, rate: Math.round(s.processed / elapsed * 60 * 10) / 10, eta: "Done" }));
      setStep("complete");
    }
  }

  function togglePause() {
    pausedRef.current = !pausedRef.current;
    setIsPaused(pausedRef.current);
  }

  function doDownload(partial = false) {
    if (!resultsRef.current.length) return;
    const ts = new Date().toISOString().slice(0, 19).replace(/[:.]/g, "-");
    downloadCSV(resultsRef.current, `plc-direct-${partial ? "partial-" : ""}${ts}.csv`);
  }

  function reset() {
    stoppedRef.current = true;
    setStep("upload");
    setFileInfo(null);
    setRows([]);
    setHeaders([]);
    resultsRef.current = [];
  }

  const progress = rows.length > 0 ? Math.round((disp.processed / rows.length) * 100) : 0;
  const estMin = fileInfo ? Math.round(fileInfo.count / Math.max(concurrency * 10, 1)) : 0;
  const estStr = estMin < 60 ? `~${estMin}m` : `~${(estMin / 60).toFixed(1)}h`;
  const canStart = !!(colMap.pn && colMap.brand);

  return (
    <>
      {/* Header */}
      <header className="site-header">
        <div className="logo">
          <div className="logo-mark">PLC</div>
          <div>
            <div className="logo-text">PLC Direct</div>
            <div className="logo-sub">Product Content Generator</div>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          {showPwInput && (
            <input
              type="password"
              placeholder="Team password"
              value={teamPassword}
              onChange={e => {
                setTeamPassword(e.target.value);
                localStorage.setItem("plc_team_password", e.target.value);
              }}
              style={{ width: 160, fontSize: 12, padding: "5px 8px" }}
            />
          )}
          <button
            className="btn btn-secondary"
            style={{ fontSize: 12, padding: "5px 12px" }}
            onClick={() => setShowPwInput(v => !v)}
          >
            {showPwInput ? "Done" : "⚙ Settings"}
          </button>
        </div>
      </header>

      <div className="page-wrap">
        <Steps step={step} />

        {/* ── Upload ── */}
        {step === "upload" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div
              className={`drop-zone ${dragOver ? "active" : ""}`}
              onDragOver={e => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={e => { e.preventDefault(); setDragOver(false); loadFile(e.dataTransfer.files[0]); }}
              onClick={() => document.getElementById("__fi").click()}
            >
              <div style={{ fontSize: 40, marginBottom: 12 }}>📂</div>
              <div style={{ fontSize: 15, fontWeight: 500, color: "var(--text)", marginBottom: 6 }}>
                Drop your CSV file here
              </div>
              <div style={{ fontSize: 13, color: "var(--text2)", marginBottom: 14 }}>or click to browse</div>
              <div style={{ display: "inline-block", fontSize: 12, color: "var(--text3)", background: "var(--bg2)", border: "0.5px solid var(--border)", borderRadius: "var(--radius-sm)", padding: "6px 14px", lineHeight: 1.8 }}>
                Required: <code>part_number</code>, <code>brand</code> &nbsp;·&nbsp; Optional: <code>context</code>
              </div>
              <input id="__fi" type="file" accept=".csv" style={{ display: "none" }} onChange={e => loadFile(e.target.files[0])} />
            </div>

            {/* Format example */}
            <div className="card">
              <div className="card-head">
                <span style={{ fontSize: 12, fontWeight: 500, color: "var(--text2)" }}>Expected CSV format</span>
                <span className="tag tag-blue">Example</span>
              </div>
              <div style={{ overflowX: "auto" }}>
                <table className="data-table">
                  <thead><tr>{["part_number","brand","context"].map(h => <th key={h}>{h}</th>)}</tr></thead>
                  <tbody>
                    {[["6ES7214-1AG40-0XB0","Siemens","S7-1200 CPU, 14DI/10DO"],
                      ["ACS310-03E-01A3-4","ABB","AC drive, 0.37kW"],
                      ["NX1P2-9024DT1","Omron","NX1P2 CPU unit"]
                    ].map((row, i) => (
                      <tr key={i}>{row.map((v, j) => <td key={j}>{v}</td>)}</tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ── Preview ── */}
        {step === "preview" && fileInfo && (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {/* File summary */}
            <div style={{ display: "flex", gap: 10 }}>
              {[["File", fileInfo.name], ["Products", Number(fileInfo.count).toLocaleString()], ["Size", `${fileInfo.size} KB`]].map(([l, v]) => (
                <div key={l} className="metric-box" style={{ flex: 1 }}>
                  <div className="metric-label">{l}</div>
                  <div style={{ fontSize: 13, fontWeight: 500, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{v}</div>
                </div>
              ))}
              <button className="btn btn-secondary" style={{ alignSelf: "stretch", fontSize: 12, padding: "0 14px" }} onClick={() => { setStep("upload"); setFileInfo(null); }}>
                Change
              </button>
            </div>

            {/* Column mapping */}
            <div className="card">
              <div className="card-head">
                <span style={{ fontSize: 13, fontWeight: 500 }}>Column mapping</span>
                {canStart && <span className="tag tag-green">Ready</span>}
              </div>
              <div className="card-body">
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                  {[["Part Number *","pn"],["Brand *","brand"],["Context (optional)","ctx"]].map(([label, key]) => (
                    <div key={key}>
                      <label>{label}</label>
                      <select value={colMap[key]} onChange={e => setColMap(m => ({ ...m, [key]: e.target.value }))}>
                        <option value="">— not mapped —</option>
                        {headers.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Preview table */}
            <div className="card">
              <div className="card-head">
                <span style={{ fontSize: 12, fontWeight: 500, color: "var(--text2)" }}>Data preview — first 5 rows</span>
              </div>
              <div style={{ overflowX: "auto" }}>
                <table className="data-table">
                  <thead><tr>{headers.map(h => <th key={h}>{h}</th>)}</tr></thead>
                  <tbody>
                    {rows.slice(0, 5).map((row, i) => (
                      <tr key={i}>{headers.map(h => <td key={h}>{row[h]}</td>)}</tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Speed */}
            <div className="card">
              <div className="card-head">
                <span style={{ fontSize: 13, fontWeight: 500 }}>Processing speed</span>
                <span style={{ fontSize: 12, color: "var(--text2)", fontFamily: "monospace" }}>{concurrency} workers · est. {estStr}</span>
              </div>
              <div className="card-body">
                <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 12 }}>
                  <span style={{ fontSize: 12, color: "var(--text3)", whiteSpace: "nowrap" }}>Safer</span>
                  <input type="range" min={1} max={15} step={1} value={concurrency} onChange={e => setConcurrency(Number(e.target.value))} />
                  <span style={{ fontSize: 12, color: "var(--text3)", whiteSpace: "nowrap" }}>Faster</span>
                  <span style={{ fontSize: 20, fontWeight: 600, minWidth: 28, textAlign: "right", fontFamily: "monospace" }}>{concurrency}</span>
                </div>
                <div className="alert-info">
                  Start at 5. Increase gradually if no rate limit errors appear. For 50k+ products, keep the tab open — or use the Python script for overnight unattended runs.
                </div>
              </div>
            </div>

            <button
              className={`btn btn-primary btn-full btn-lg`}
              disabled={!canStart}
              onClick={startProcessing}
            >
              {canStart ? `Generate content for ${Number(fileInfo.count).toLocaleString()} products →` : "Map Part Number and Brand columns to continue"}
            </button>
          </div>
        )}

        {/* ── Processing ── */}
        {step === "processing" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {/* Progress */}
            <div className="card">
              <div className="card-body">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ width: 8, height: 8, borderRadius: "50%", background: isPaused ? "var(--text3)" : "#1D9E75", display: "inline-block" }} className={isPaused ? "" : "pulse"} />
                    <span style={{ fontSize: 13, fontWeight: 500 }}>{isPaused ? "Paused" : "Processing…"}</span>
                  </div>
                  <span style={{ fontSize: 13, fontFamily: "monospace", color: "var(--text2)" }}>
                    {disp.processed.toLocaleString()} / {rows.length.toLocaleString()} &nbsp;·&nbsp; {progress}%
                  </span>
                </div>
                <div className="progress-bar-track">
                  <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
                </div>
              </div>
            </div>

            {/* Metrics */}
            <div className="metric-grid metric-grid-4">
              <div className="metric-box"><div className="metric-label">Processed</div><div className="metric-value">{disp.processed.toLocaleString()}</div></div>
              <div className="metric-box"><div className="metric-label">Succeeded</div><div className={`metric-value ${disp.succeeded > 0 ? "green" : ""}`}>{disp.succeeded.toLocaleString()}</div></div>
              <div className="metric-box"><div className="metric-label">Failed</div><div className={`metric-value ${disp.failed > 0 ? "red" : ""}`}>{disp.failed.toLocaleString()}</div></div>
              <div className="metric-box"><div className="metric-label">Rate</div><div className="metric-value">{disp.rate}/min</div></div>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: "var(--text2)" }}>
              <span>ETA: <strong style={{ color: "var(--text)" }}>{disp.eta}</strong></span>
              <span>{concurrency} parallel workers</span>
            </div>

            {/* Live feed */}
            <div className="card">
              <div className="card-head">
                <span style={{ fontSize: 11, fontWeight: 500, color: "var(--text2)", textTransform: "uppercase", letterSpacing: "0.06em" }}>Live feed</span>
                <span style={{ fontSize: 11, color: "var(--text3)" }}>last 10 completed</span>
              </div>
              {recentItems.length === 0
                ? <div style={{ padding: "1.25rem", fontSize: 13, color: "var(--text3)", textAlign: "center" }}>Starting workers…</div>
                : recentItems.map((item, i) => (
                  <div key={i} className="feed-item">
                    <span className={item.status === "success" ? "feed-status-ok" : "feed-status-err"}>{item.status === "success" ? "✓" : "✗"}</span>
                    <span className="feed-pn">{item.pn}</span>
                    <span className="feed-brand">{item.brand}</span>
                    {item.name && <span className="feed-name">{item.name}</span>}
                  </div>
                ))
              }
            </div>

            {/* Controls */}
            <div style={{ display: "flex", gap: 10 }}>
              <button className="btn btn-secondary" style={{ flex: 1 }} onClick={togglePause}>
                {isPaused ? "▶ Resume" : "⏸ Pause"}
              </button>
              <button
                className="btn btn-primary"
                style={{ flex: 2 }}
                disabled={disp.processed === 0}
                onClick={() => doDownload(true)}
              >
                ↓ Download partial ({disp.processed.toLocaleString()} ready)
              </button>
            </div>
          </div>
        )}

        {/* ── Complete ── */}
        {step === "complete" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div className="card">
              <div className="card-body" style={{ textAlign: "center", padding: "2.5rem 1rem" }}>
                <div style={{ fontSize: 48, marginBottom: 12 }}>✓</div>
                <div style={{ fontSize: 20, fontWeight: 500, marginBottom: 6 }}>Batch complete</div>
                <div style={{ fontSize: 13, color: "var(--text2)" }}>
                  {disp.succeeded.toLocaleString()} products generated successfully
                  {disp.failed > 0 && <span style={{ color: "var(--red)" }}> · {disp.failed.toLocaleString()} failed</span>}
                </div>
              </div>
            </div>

            <div className="metric-grid metric-grid-3">
              {[["Total", disp.processed.toLocaleString()], ["Succeeded", disp.succeeded.toLocaleString()], ["Failed", disp.failed.toLocaleString()]].map(([l, v]) => (
                <div key={l} className="metric-box" style={{ textAlign: "center" }}>
                  <div className="metric-label">{l}</div>
                  <div className="metric-value">{v}</div>
                </div>
              ))}
            </div>

            {disp.failed > 0 && (
              <div className="alert-warning">
                {disp.failed} products failed — they're included in the CSV with <code>status=failed</code> so you can reprocess them.
              </div>
            )}

            <button className="btn btn-primary btn-full btn-lg" onClick={() => doDownload(false)}>
              ↓ Download results CSV ({disp.processed.toLocaleString()} rows)
            </button>
            <button className="btn btn-secondary btn-full" onClick={reset}>
              Process another file
            </button>
          </div>
        )}
      </div>
    </>
  );
}
