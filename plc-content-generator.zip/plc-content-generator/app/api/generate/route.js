import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const SYSTEM_PROMPT = `You are a product content specialist for PLC Direct, a US-based industrial automation products distributor. PLC Direct sells surplus, refurbished, and used equipment from 40+ major brands including Siemens, ABB, Omron, Mitsubishi, Schneider, Fanuc, Sick, Yaskawa, Beckhoff, Rockwell, Allen-Bradley, and others.

Generate comprehensive, accurate product content. Return ONLY a valid JSON object — no markdown, no backticks, no preamble.

{
  "productName": "Full descriptive product name",
  "brand": "Brand name",
  "partNumber": "Part number as given",
  "shortDescription": "One compelling sentence under 30 words describing what this product is and its primary function.",
  "overview": "3-4 sentences: what it is, its role in automation systems, standout characteristics, and why engineers choose it.",
  "productInformation": {
    "Product Type": "...",
    "Series / Family": "...",
    "Form Factor": "...",
    "Condition (PLC Direct)": "Surplus / Refurbished / Used",
    "Warranty": "1 Year (PLC Direct)",
    "Shipping": "Free (US)",
    "Availability": "Subject to stock"
  },
  "keyBenefits": ["Benefit 1", "Benefit 2", "Benefit 3", "Benefit 4", "Benefit 5"],
  "technicalSpecifications": {
    "Spec name": "Value — include all known specs: I/O counts, voltage, current, protocols, dimensions, weight, temp range, certifications, memory, etc."
  },
  "additionalBenefits": ["Benefit 1", "Benefit 2", "Benefit 3"],
  "applications": ["Use case 1", "Use case 2", "Use case 3", "Use case 4"],
  "facets": {
    "Category": "PLC / HMI / Drive / Sensor / I/O Module / Power Supply / Safety / Communication / Motion Control",
    "Brand": "Brand name",
    "Series": "Product series or family",
    "Product Type": "Specific product type",
    "Communication Protocols": ["protocol1", "protocol2"],
    "Industries": ["Industry 1", "Industry 2", "Industry 3"],
    "Tags": ["tag1", "tag2", "tag3", "tag4", "tag5"]
  },
  "criticalInformation": [
    "Programming software or firmware requirement",
    "Surplus/used condition consideration",
    "Compatibility or safety note"
  ]
}`;

export async function POST(request) {
  try {
    // Optional: simple team password check
    const teamPassword = process.env.TEAM_PASSWORD;
    if (teamPassword) {
      const authHeader = request.headers.get("x-team-password");
      if (authHeader !== teamPassword) {
        return Response.json({ error: "Unauthorized" }, { status: 401 });
      }
    }

    const { pn, brand, ctx } = await request.json();

    if (!pn || !brand) {
      return Response.json({ error: "part_number and brand are required" }, { status: 400 });
    }

    const userMsg = `Generate complete product content for:\nPart Number: ${pn}\nBrand: ${brand}${ctx ? "\nAdditional context: " + ctx : ""}`;

    const response = await client.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1500,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: userMsg }],
    });

    const raw = response.content
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("")
      .trim()
      .replace(/```json|```/g, "")
      .trim();

    const data = JSON.parse(raw);
    return Response.json({ success: true, data });

  } catch (err) {
    if (err.status === 429) {
      return Response.json({ error: "rate_limit" }, { status: 429 });
    }
    console.error("Generate error:", err);
    return Response.json({ error: err.message || "Internal error" }, { status: 500 });
  }
}
